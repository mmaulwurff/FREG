-------------------------------------------------------------
template for freg help file
===========================

You can use Markdown syntax. For example,

    this is code

This is code in text: `i am code`.

This is link: <https://github.com/mmaulwurff/FREG>

[Link with name](https://github.com/mmaulwurff/FREG)

1. Numbered
2. list

*italic* **bold**

- this
- is
- simple
- list

Also, to be visible in text (curses) version of freg,
text width should not exceed 61 character and
file should not contain more than 32 lines.

-------------------------------------------------------------
