-------------------------------------------------------------
Freg help. Game commands:
=========================

Key | function
--- | --------
'Q'               | quit game
'H'               | this help
arrows, NumPad    | turn and move in four directions
'='               | move to your current direction
End               | move down
'>', '<'          | turn right and left
space             | jump
Page Up           | look up
Page Down         | loo down
Home, 'I'         | inventory
Backspace, Delete | hit
Enter, 'E'        | use
Esc               | stop using everything
'?'               | examine
'~'               | inscribe
'!'               | enter/leave creative mode
':', '/'          | enter command mode (leave with enter)
'.'               | repeat last command
'L', 'R'          | redraw screen
'-', '+'          | shift focus down and up
'S'               | shake inventory
'a'-'z' | make inventory action with this inventory slot

-------------------------------------------------------------
